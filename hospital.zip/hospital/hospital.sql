-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2022 at 01:45 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `doctor_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `age` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `blood` varchar(5) NOT NULL,
  `address` varchar(250) NOT NULL,
  `doj` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`doctor_id`, `name`, `password`, `fname`, `contact`, `email`, `age`, `gender`, `blood`, `address`, `doj`) VALUES
('aa', 'a', '', 'a', 'a', 'a@gmail.com', 'a', 'Male', 'A', 'aaa', '2022-06-02'),
('av', 'abc', '1234', 'a', 'a', 'a@gmail.com', 'm.tech', 'Female', 'O-', 'sss', '2022-06-02');

-- --------------------------------------------------------

--
-- Table structure for table `patent_details`
--

CREATE TABLE `patent_details` (
  `patent_id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `age` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `blood` varchar(5) NOT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patent_details`
--

INSERT INTO `patent_details` (`patent_id`, `name`, `password`, `fname`, `contact`, `email`, `age`, `gender`, `blood`, `address`) VALUES
('1', '1', '', '1', '1', '1', '1', '1', '1', '1'),
('1234', 'datta', '1234', 'datta', '123456790', 'b@gmail.com', '29', 'Male', 'A', 'aaa'),
('24', 'balaji', '', 'bala', '912345678', 'a@gmail.com', '23', 'Male', 'B+', 'adddd'),
('2653', 'abc', '1234', 'abcd', '987564321', 'a@gmail.com', '25', 'Female', 'O+', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `rno` varchar(20) NOT NULL,
  `rtype` varchar(20) NOT NULL,
  `rcharges` varchar(20) NOT NULL,
  `rstatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `rno`, `rtype`, `rcharges`, `rstatus`) VALUES
(1, '230', 'ac', '1300', 'booked');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_name` varchar(50) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `service_date` date NOT NULL,
  `patent_name` varchar(50) NOT NULL,
  `service_charges` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_name`, `patient_id`, `service_date`, `patent_name`, `service_charges`) VALUES
('eeee', '2356', '2022-06-08', 'datta', 5000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor_details`
--
ALTER TABLE `doctor_details`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patent_details`
--
ALTER TABLE `patent_details`
  ADD PRIMARY KEY (`patent_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
