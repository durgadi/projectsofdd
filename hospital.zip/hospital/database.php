<?php
         $dbuser = "root";
         $dbpass = "";
         $hostname = "localhost";
         $val=0;
         $dbhandle = mysql_connect($hostname, $dbuser, $dbpass)  or die("Unable to connect to MySQL");
         $selected = mysql_select_db("hospital",$dbhandle)   or die("unable to connect");
?>

<?php
$servername='localhost';
$username='root';
$password='';
$dbname = "hospital";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>
<?php
$con= mysqli_connect("localhost","root","","hospital") or die("Error: " . mysqli_error($con));
mysqli_query($con, "SET NAMES 'utf8' ");
 
?>
