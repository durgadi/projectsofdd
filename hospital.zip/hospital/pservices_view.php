<?php session_start();
$id=$_SESSION['name'];?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Hospital Management System</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid nav-bar p-0">
        <div class="container-lg p-0">
            <nav class="navbar navbar-expand-lg bg-secondary navbar-dark">
                <a href="index.php" class="navbar-brand">
                    <h1 class="m-0 text-white display-4"><span class="text-primary">H</span>ospital<span class="text-primary">M</span>anagement</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">
                         <a href="index.php" class="nav-item nav-link">Home</a>
						<div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Services</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="pservices_view.php" class="dropdown-item">Services</a>
                                <a href="proom_view.php" class="dropdown-item">Rooms</a>
								</div>
                            </div>
                        
						<div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" >View</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="patient_view.php" class="dropdown-item">Patient</a>
								<a href="pdoctor_view.php" class="dropdown-item">Doctor</a>
                                
                            </div>
                        </div>
						<a href="logout.php" class="nav-item nav-link">Logout</a>
                    </div>
					
                        
                </div>
            </nav>
        </div>
    </div>


    <!-- Page Header Start -->
    <div class="container-fluid page-header d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5 mb-5">
        <h1 class="display-4 text-white mb-3 mt-0 mt-lg-5">Get the Service Details</h1>
        
    </div>
    <!-- Page Header Start -->


    <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <?php echo "<h2 align='right'><font color=red>$id</font></h2>";?>
            <div class="row">
                <div class="col-md-5">
                    <?php 
include('database.php');   
 ?>
   <form>
   <center>

   <?php 
    $sno=1;
	
	
    $res1=mysql_query("select *from services where patent_name='$id'");
   ?>
	<br><br>
	<font size=4>
	<center><table border=1 width=100%>
	<tr bgcolor=blue><th colspan=10><font color=white><center>Service Details</center></font></th></tr>
	<tr><th>S.No</th>
		<th>Service&nbsp;&nbsp;Name</th>
		<th>Service&nbsp;&nbsp;Date</th>
		<th>Patent&nbsp;&nbsp;Id</th>
		<th>Patent&nbsp;&nbsp;Name</th>
		<th>Service&nbsp;&nbsp;Charges</th></tr>
		
	
	
    
	<?php
	while($info = mysql_fetch_array($res1)) 
          {
          echo "<tr align=center><td>".$sno."</td>
								 <td>".strtoupper($info['service_name'])."</td>
								 <td>".strtoupper($info['service_date'])."</td>
								 <td>".strtoupper($info['patient_id'])."</td>
								 <td>".strtoupper($info['patent_name'])."</td>
								 <td>".strtoupper($info['service_charges'])."</td>
								 </tr>";   
          $sno++;
		  }        
	
	 ?>
	 
	  </table>
                    
                    
                </div>
                
            </div>
        </div>
    </div></center>
    <!-- Contact End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-white mt-5 pt-5 px-sm-3 px-md-5">
        <div class="row pt-5">
            
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Quick Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white mb-2" href="index.php"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
					<a class="text-white mb-2" href="pdoctor_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Doctors</a>
                    <a class="text-white mb-2" href="patient_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>View</a>
					<a class="text-white mb-2" href="proom_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Rooms</a>
					<a class="text-white mb-2" href="pservices_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Services</a>
                    </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Popular Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white mb-2" href="index.php"><i class="fa fa-angle-right text-primary mr-2"></i>Home</a>
					<a class="text-white mb-2" href="pdoctor_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Doctors</a>
                    <a class="text-white mb-2" href="patient_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>View</a>
                    <a class="text-white mb-2" href="proom_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Rooms</a>
					<a class="text-white mb-2" href="pservices_view.php"><i class="fa fa-angle-right text-primary mr-2"></i>Services</a>
					
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="font-weight-bold text-primary mb-4">Hosiptal Management System</h5>
                <p>Tadepalligudem</p>
                <p><i class="fa fa-map-marker-alt text-primary mr-2"></i>West Godavari, Andhra Pradesh</p>
                <p><i class="fa fa-phone-alt text-primary mr-2"></i>7995661681</p>
                <p><i class="fa fa-envelope text-primary mr-2"></i>hms@gmail.com</p>
            </div>
        </div>
    </div>
    <div class="container-fluid py-4 px-sm-3 px-md-5">
        <p class="m-0 text-center">
            <?php echo date("Y");?>&copy; <a class="font-weight-semi-bold" href="#">Hosiptal Management System</a>. All Rights Reserved. Designed by
            <a class="font-weight-semi-bold" href="#">CSE Dept</a>
        </p>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
<?php
include('database.php');
if(isset($_POST['submit']))  
{  
	$doctor_id= $_POST['doctor_id'];
	$name=$_POST['name'];  
	$fname=$_POST['fname'];  
	$contact=$_POST['contact'];  
	$email=$_POST['email'];  
	$age=$_POST['age'];  
	$gender=$_POST['gender'];  
	$blood=$_POST['blood'];  
	$address=$_POST['address'];  
	$doj=$_POST['doj'];  
	$in_ch=mysqli_query($con,"insert into doctor_details(doctor_id, name, fname, contact, email,  age, gender, blood, address,doj ) values ('$doctor_id','$name','$fname','$contact','$email','$age','$gender','$blood','$address','$doj')");  
if($in_ch==1)  
   {  
      echo'<script>alert("Details Uploaded Successfully")</script>';  
   }  
else  
   {  
      echo'<script>alert("Failed To Uploaded")</script>';  
   }  
}
?>  

